package com.cts.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.project.exception.InvalidPensionerException;
import com.cts.project.exception.InvalidTokenException;
import com.cts.project.model.PensionerDetail;
import com.cts.project.proxy.AuthServiceProxy;
import com.cts.project.repository.PensionerDetailRepo;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PensionerDetailDbServiceImpl implements PensionerDetailService {

	@Autowired
	private PensionerDetailRepo pensionerDetailRepo;

	@Autowired
	private AuthServiceProxy authServiceProxy;

	@Override
	public PensionerDetail findAadhaar(String token, String aadhaarNo)
			throws InvalidPensionerException, InvalidTokenException {

		log.info("BEGIN   -   [findAadhaarInDatabase()]");
		try {
			if (!authServiceProxy.validateToken(token)) {
				throw new InvalidTokenException("Token is Invalid");
			}
		} catch (FeignException e) {
			throw new InvalidTokenException("Token is Invalid or Expired");
		}
		PensionerDetail pensionerDetail = pensionerDetailRepo.findById(aadhaarNo)
				.orElseThrow(() -> new InvalidPensionerException("Aadhaar Number doesn't exist in the database."));
		log.debug("Pensioner Detail :=" + pensionerDetail);
		log.info("END   -   [findAadhaarInDatabase()]");

		return pensionerDetail;
	}

}
