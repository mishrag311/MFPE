package com.cts.project.processpensionmicroservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cts.project.processpensionmicroservice.exception.AadharNotFoundException;
import com.cts.project.processpensionmicroservice.exception.InvalidDetailsEnteredException;
import com.cts.project.processpensionmicroservice.exception.InvalidTokenException;
import com.cts.project.processpensionmicroservice.model.Bank;
import com.cts.project.processpensionmicroservice.model.PensionDetail;
import com.cts.project.processpensionmicroservice.model.PensionerDetail;
import com.cts.project.processpensionmicroservice.model.PensionerInput;
import com.cts.project.processpensionmicroservice.model.ProcessPensionInput;
import com.cts.project.processpensionmicroservice.proxy.AuthServiceProxy;
import com.cts.project.processpensionmicroservice.proxy.PensionDisbursementMicroservivceProxy;
import com.cts.project.processpensionmicroservice.proxy.PensionerDetailMicroserviceProxy;
import com.cts.project.processpensionmicroservice.util.ValidatePensionerDetails;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcessPensionServiceImpl implements ProcessPensionService {

	@Autowired
	private PensionerDetailMicroserviceProxy pensionerDetailProxy;

	@Autowired
	private PensionDisbursementMicroservivceProxy pensionDisbursementProxy;

	@Autowired
	private AuthServiceProxy authServiceProxy;
	
	@Value("${privatebank.charge}")
	private double privateBankCharge;

	@Value("${publicbank.charge}")
	private double publicBankCharge;
	
	private static String privateBank = "private";
	private static String publicBank = "public";
	private static List<Bank> bankList;

	static {
		bankList = List.of(new Bank("HDFC", privateBank), new Bank("ICICI", privateBank), new Bank("Axis", privateBank),
				new Bank("SBI", publicBank), new Bank("PNB", publicBank), new Bank("Central Bank", publicBank),
				new Bank("Indian Bank", publicBank), new Bank("Oriental Bank of Commerce", publicBank),
				new Bank("Bandhan Bank", privateBank), new Bank("Co-Operative Bank", publicBank),
				new Bank("Allahabad", publicBank), new Bank("BOB", publicBank), new Bank("Yes", privateBank));
	}

	@Override
	public PensionDetail getPensionDetails(String token, PensionerInput pensionerInput)
			throws InvalidDetailsEnteredException, InvalidTokenException, AadharNotFoundException {
		log.info("BEGIN   -   [getPensionDetails()]");

		try {
			if (!authServiceProxy.validateToken(token)) {
				throw new InvalidTokenException("Token is Invalid");
			}
		} catch (FeignException e) {
			throw new InvalidTokenException("Token is Invalid or Expired");
		}

		log.debug("Pensioner Input : " + pensionerInput);

		double pensionAmount = 0;
		PensionerDetail pensionerDetail = null;
		try {
			pensionerDetail = pensionerDetailProxy.fetchPensionerDetaiByAadhaar(token,
					pensionerInput.getAadharNumber());
		} catch (FeignException ex) {
			throw new AadharNotFoundException("Aadhaar Number doesn't exist in the database.");
		}
		log.debug("Pensioner Details : " + pensionerDetail);

		if (!ValidatePensionerDetails.isValidDetails(pensionerInput, pensionerDetail)) {
			throw new InvalidDetailsEnteredException("Invalid pensioner detail provided, please provide valid detail.");
		}

		if (pensionerDetail.getPensionType().equalsIgnoreCase("self")) {
			pensionAmount = 0.8 * pensionerDetail.getSalaryEarned() + pensionerDetail.getAllowances();
		} else if (pensionerDetail.getPensionType().equalsIgnoreCase("family")) {
			pensionAmount = 0.5 * pensionerDetail.getSalaryEarned() + pensionerDetail.getAllowances();
		}

		log.debug("Pension Calculated : " + pensionAmount);
		log.info("END   -   [getPensionDetails()]");

		return new PensionDetail(pensionerDetail.getPensionerName(), pensionerDetail.getPensionerDob(),
				pensionerDetail.getPensionerPAN(), pensionerDetail.getPensionType(), pensionAmount);
	}

	@Override
	public Integer getResponse(String token, ProcessPensionInput processPensionInput) throws InvalidTokenException {
		log.info("BEGIN   -   [getResponse()]");

		try {
			if (!authServiceProxy.validateToken(token)) {
				throw new InvalidTokenException("Token is Invalid");
			}
		} catch (FeignException e) {
			throw new InvalidTokenException("Token is Invalid or Expired");
		}

		log.debug("Process Pension Input : " + processPensionInput);

		PensionerDetail pensionerDetail = pensionerDetailProxy.fetchPensionerDetaiByAadhaar(token,
				processPensionInput.getAadharNumber());
		log.debug("Pensioner Details : " + pensionerDetail);

		Optional<Bank> userBank = bankList.stream()
				.filter(bank -> bank.getName().equalsIgnoreCase(pensionerDetail.getBankDetail().getBankName()))
				.findFirst();
		log.debug("Bank Details : " + userBank);

		if (userBank.isPresent() && userBank.get().getBankType().equalsIgnoreCase(publicBank)) {
			processPensionInput.setBankCharge(publicBankCharge);
		} else if (userBank.isPresent() && userBank.get().getBankType().equalsIgnoreCase(privateBank)) {
			processPensionInput.setBankCharge(privateBankCharge);
		}

		int tryForResponseCode = 3;
		int responseCode = 21;
		while (tryForResponseCode-- > 0) {
			responseCode = pensionDisbursementProxy.getPensionDisbursement(token, processPensionInput);
			if (responseCode == 10) {
				break;
			}
		}

		log.debug("Response Code Retuned : " + responseCode);

		log.info("END   -   [getResponse()]");
		return responseCode;
	}

}
