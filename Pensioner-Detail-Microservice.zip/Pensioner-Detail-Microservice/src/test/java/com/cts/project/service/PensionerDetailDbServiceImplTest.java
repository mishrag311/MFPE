package com.cts.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.Month;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.project.exception.InvalidPensionerException;
import com.cts.project.exception.InvalidTokenException;
import com.cts.project.model.BankDetail;
import com.cts.project.model.PensionerDetail;
import com.cts.project.proxy.AuthServiceProxy;
import com.cts.project.repository.PensionerDetailRepo;

@SpringBootTest
class PensionerDetailDbServiceImplTest {

	@InjectMocks
	private PensionerDetailDbServiceImpl pensionerDetailService;

	@Mock
	private PensionerDetailRepo pensionerDetailRepo;

	@Mock
	private AuthServiceProxy authProxy;

	@Test
	void testFindById() throws InvalidPensionerException, InvalidTokenException {
		String token = "dummy";
		when(pensionerDetailRepo.findById("0123456789")).thenReturn(
				Optional.of(new PensionerDetail("0123456789", "Gaurav", LocalDate.of(2000, Month.JANUARY, 31),
						"ELT014XZ", 30000.0, 50000.0, "Self", new BankDetail("ICICI", "AC001", "Private"))));
		when(authProxy.validateToken(token)).thenReturn(true);
		PensionerDetail pensionerDetail = pensionerDetailService.findAadhaar(token, "0123456789");
		assertEquals("0123456789", pensionerDetail.getAadhaarNumber());
		assertEquals("Gaurav", pensionerDetail.getPensionerName());
		assertEquals(LocalDate.of(2000, Month.JANUARY, 31), pensionerDetail.getPensionerDob());
	}

}
