package com.cts.training.webclient.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.cts.training.webclient.feign.AuthenticationClient;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TokenCheckServiceImpl implements TokenCheckService {

	@Autowired
	private AuthenticationClient authenticationClient;

	@Override
	public ModelAndView checkStatus(HttpServletRequest request) {
		if (request.getSession().getAttribute("token") == null) {
			log.debug("User not logged in. Redirecting to login page");
			return new ModelAndView(new RedirectView("login"));
		}
		String token = request.getSession().getAttribute("token").toString();
		try {
			if (!authenticationClient.validateToken(token)) {
				log.debug("Token is either invalid or expired. Redirecting to login page");
				return new ModelAndView(new RedirectView("session-expired"));
			}
		} catch (Exception e) {
			log.debug("Token is either invalid or expired. Redirecting to login page");
			return new ModelAndView(new RedirectView("session-expired"));
		}
		return null;
	}

}
