package com.cts.project.controller;

import com.cts.project.exception.TokenInvalidException;
import com.cts.project.model.ProcessPensionInput;
import com.cts.project.service.PensionDisbursementService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PensionDisbursementController {

	@Autowired
	private PensionDisbursementService pensionDisbursementService;

	@PostMapping("/disbursepension")
	@ApiOperation(value = "getPensionDisbursement", notes = "returns success code or failure code as Integer", httpMethod = "POST", response = Integer.class)
	public Integer getPensionDisbursement(@RequestHeader(name = "Authorization") String token,
			@RequestBody ProcessPensionInput processPensionInput) throws TokenInvalidException {
		log.info("Begin - [getPensionDisbursement()]");
		Integer returnCode = pensionDisbursementService.getPensionDisbursement(token, processPensionInput);
		log.debug("Return Code :=" + returnCode);
		log.info("END - [getPensionDisbursement()]");
		return returnCode;

	}

	@GetMapping("/health-check")
	public ResponseEntity<String> healthCheck() {
		return new ResponseEntity<>("OK", HttpStatus.OK);
	}

}