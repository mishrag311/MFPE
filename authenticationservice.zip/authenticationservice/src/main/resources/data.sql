insert into user_login (user_name, password) values ('user1', 'user1');
insert into user_login (user_name, password) values ('user2', 'user2');
insert into user_login (user_name, password) values ('user3', 'user3');
insert into user_login (user_name, password) values ('user4', 'user4');
insert into user_login (user_name, password) values ('user5', 'user5');