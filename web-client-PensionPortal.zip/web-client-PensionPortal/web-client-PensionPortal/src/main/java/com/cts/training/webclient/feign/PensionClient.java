package com.cts.training.webclient.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.training.webclient.model.PensionDetail;
import com.cts.training.webclient.model.PensionerInput;
import com.cts.training.webclient.model.ProcessPensionInput;

@FeignClient(name = "process-pension-microservice", url = "${processpension.feign.dns}")
public interface PensionClient {

	@PostMapping("/PensionDetail")
	public PensionDetail getPensionDetail(@RequestHeader(name = "Authorization") String token,
			@RequestBody PensionerInput pensionerInput);

	@PostMapping("/ProcessPension")
	public Integer processPension(@RequestHeader(name = "Authorization") String token,
			@RequestBody ProcessPensionInput processPensionInput);

}
