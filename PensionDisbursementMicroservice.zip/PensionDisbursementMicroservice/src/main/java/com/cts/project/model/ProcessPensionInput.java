package com.cts.project.model;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ApiModel(value = "Model class for Process Pension Input")
public class ProcessPensionInput {
	@ApiModelProperty(value = "Aadhar Number of the Pensioner")
	private String aadharNumber;
	@ApiModelProperty(value = "Pension amount of the Pensioner")
	private double pensionAmount;
	@ApiModelProperty(value = "Bank charges based on Bank Type")
	private double bankCharge;
}
