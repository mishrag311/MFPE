package com.cts.project.processpensionmicroservice.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import com.cts.project.processpensionmicroservice.exception.AadharNotFoundException;
import com.cts.project.processpensionmicroservice.exception.InvalidDetailsEnteredException;
import com.cts.project.processpensionmicroservice.exception.InvalidTokenException;
import com.cts.project.processpensionmicroservice.model.PensionDetail;
import com.cts.project.processpensionmicroservice.model.PensionerInput;
import com.cts.project.processpensionmicroservice.model.ProcessPensionInput;
import com.cts.project.processpensionmicroservice.proxy.AuthServiceProxy;
import com.cts.project.processpensionmicroservice.service.ProcessPensionServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
class ProcessPensionControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ProcessPensionController processPensionController;
	
	@MockBean
	private ProcessPensionServiceImpl processPensionService;
	
	@MockBean
	private AuthServiceProxy authService;

	@Test
	void contextLoads() throws Exception {
		assertThat(processPensionController).isNotNull();
	}

	@Test
	@DirtiesContext
	void testPensionDetailReturnValidDetailsForSelfPension() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1023", "1234567891234567", "self");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenReturn(new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1023", "self", 15.0));	
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1023\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"self\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(status().isOk())
				.andExpect(content().string(containsString(
						"{\"id\":1,\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1023\",\"pensionType\":\"self\",\"pensionAmount\":15.0}")));
	}
	
	@Test
	@DirtiesContext
	void testPensionDetailReturnValidDetailsForFamilyPension() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1022", "1234567891234567", "family");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenReturn(new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1022", "family", 18.0));	
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1022\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"family\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(status().isOk())
				.andExpect(content().string(containsString(
						"{\"id\":1,\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1022\",\"pensionType\":\"family\",\"pensionAmount\":18.0}")));
	}

	@Test
	void testPensionDetailReturnsExceptionOnInvalidName() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Sam", LocalDate.of(1998, 8, 3), "FBCJ1022", "1234567891234567", "family");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(new InvalidDetailsEnteredException("Invalid pensioner detail provided, please provide valid detail."));
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Sam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1022\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"family\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof InvalidDetailsEnteredException))
				.andExpect(result -> assertEquals("Invalid pensioner detail provided, please provide valid detail.",
						result.getResolvedException().getMessage()));
	}
	
	@Test
	void testPensionDetailReturnsExceptionOnInvalidDateOfBirth() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(2000, 10, 10), "FBCJ1022", "1234567891234567", "family");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(new InvalidDetailsEnteredException("Invalid pensioner detail provided, please provide valid detail."));
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"2000-10-10\",\"pan\":\"FBCJ1022\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"family\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(status().isBadRequest())
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof InvalidDetailsEnteredException))
				.andExpect(result -> assertEquals("Invalid pensioner detail provided, please provide valid detail.",
						result.getResolvedException().getMessage()));
	}
	
	@Test
	void testPensionDetailReturnsExceptionOnInvalidPan() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBGH1034", "1234567891234567", "family");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(new InvalidDetailsEnteredException("Invalid pensioner detail provided, please provide valid detail."));
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBGH1034\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"family\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(status().isBadRequest())
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof InvalidDetailsEnteredException))
				.andExpect(result -> assertEquals("Invalid pensioner detail provided, please provide valid detail.",
						result.getResolvedException().getMessage()));
	}
	
	@Test
	void testPensionDetailReturnsExceptionOnInvalidPensionType() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1022", "1234567891234567", "self");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(new InvalidDetailsEnteredException("Invalid pensioner detail provided, please provide valid detail."));
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1022\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"self\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(status().isBadRequest())
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof InvalidDetailsEnteredException))
				.andExpect(result -> assertEquals("Invalid pensioner detail provided, please provide valid detail.",
						result.getResolvedException().getMessage()));
	}
	
	@Test
	void testProcessPensionWhenDetailsAreValid() throws Exception {
		String token = "dummy";
		
		ProcessPensionInput processPensionInput = new ProcessPensionInput("1234567891234567", 10000, 550);
		when(processPensionService.getResponse("Bearer" + token, processPensionInput))
			.thenReturn(10);
		
		this.mockMvc
			.perform(post("/ProcessPension")
			.contentType(MediaType.APPLICATION_JSON)
			.content("{\"aadharNumber\":\"1234567891234567\",\"pensionAmount\":\"10000\"}")
			.header("Authorization", "Bearer " + token))
			.andExpect(status().isOk());
	}
	
	@Test
	void testProcessPensionWhenDetailsAreInvalid() throws Exception {
		String token = "dummy";
		
		ProcessPensionInput processPensionInput = new ProcessPensionInput("1234567891233455", 1000, 550);
		when(processPensionService.getResponse("Bearer" + token, processPensionInput))
			.thenReturn(21);
		
		this.mockMvc
			.perform(post("/ProcessPension")
			.contentType(MediaType.APPLICATION_JSON)
			.content("{\"aadharNumber\":\"1234567891233455\",\"pensionAmount\":\"1000\"}")
			.header("Authorization", "Bearer " + token))
			.andExpect(status().isOk());
	}
	
	@Test
	void testDetailsAlreadyExistInTable() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1023", "1234567891234567", "self");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(DataIntegrityViolationException.class);	
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1023\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"self\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof DataIntegrityViolationException));
	}
	
	@Test
	void testWhenAadharIsInvalid() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1023", "1234567891234567", "self");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(AadharNotFoundException.class);	
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1023\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"self\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof AadharNotFoundException));
	}
	
	@Test
	void testWhenTokenIsInvalidForPensionDetail() throws Exception {
		String token = "dummy";
		
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.of(1998, 8, 3), "FBCJ1023", "1234567891234567", "self");
		when(authService.validateToken("Bearer " + token)).thenReturn(true);
		when(processPensionService.getPensionDetails("Bearer " + token, pensionerInput))
			.thenThrow(InvalidTokenException.class);	
		
		this.mockMvc.perform(post("/PensionDetail")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"Shivam\",\"dateOfBirth\":\"1998-08-03\",\"pan\":\"FBCJ1023\",\"aadharNumber\":\"1234567891234567\",\"pensionType\":\"self\"}")
				.header("Authorization", "Bearer " + token))
				.andExpect(
						result -> assertTrue(result.getResolvedException() instanceof InvalidTokenException));
	}
}
