package com.cts.project.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.DirtiesContext;

import com.cts.project.model.BankDetail;
import com.cts.project.model.PensionerDetail;

@DataJpaTest
class PensionerDetailRepoTest {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private PensionerDetailRepo pensionerDetailRepo;

	@Test
	void testRepositoryIsNotEmpty() {
		Iterable<PensionerDetail> pensioner = pensionerDetailRepo.findAll();

		assertThat(pensioner).isNotEmpty();
	}

	@Test
	@DirtiesContext
	void testFindPensionerDetailByAadhaar() {

		PensionerDetail pensioner = new PensionerDetail("0123456789", "Gaurav", LocalDate.of(2000, Month.JANUARY, 31),
				"ELT014XZ", 30000.0, 50000.0, "Self", new BankDetail("ICICI", "AC001", "Private"));
		entityManager.persist(pensioner);
		PensionerDetail pensionerDetail = pensionerDetailRepo.findById(pensioner.getAadhaarNumber()).get();
		assertThat(pensionerDetail).isEqualTo(pensioner);
	}

}
