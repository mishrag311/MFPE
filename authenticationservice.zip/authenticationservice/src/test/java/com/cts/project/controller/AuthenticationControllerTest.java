package com.cts.project.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.cts.project.exception.CredentialsException;
import com.cts.project.model.UserLogin;
import com.cts.project.repository.UserRepository;
import com.cts.project.service.JwtUtil;
import com.cts.project.service.UserService;

import io.jsonwebtoken.SignatureException;

@SpringBootTest
class AuthenticationControllerTest {

	@InjectMocks
	private AuthenticationController authenticationController;

	@Mock
	private JwtUtil jwtUtil;

	@Mock
	private UserService userService;

	@Mock
	private UserRepository userRepository;

	@Test
	void testValidLogin() throws CredentialsException {
		UserLogin user = new UserLogin("user1", "user1");
		UserDetails userDetails = new User(user.getUserName(), user.getPassword(), new ArrayList<>());

		when(userService.loadUserByUsername("user1")).thenReturn(userDetails);
		when(jwtUtil.generateToken(userDetails)).thenReturn("dummy-token");

		ResponseEntity<Object> userToken = authenticationController.login(user);
		assertEquals(HttpStatus.OK, userToken.getStatusCode());
	}

	@Test
	void testInvalidLogin() {
		UserLogin user = new UserLogin("user1", "user2");
		UserDetails userDetails = new User(user.getUserName(), "user1", new ArrayList<>());

		when(userService.loadUserByUsername("user1")).thenReturn(userDetails);
		Exception exception = Assertions.assertThrows(CredentialsException.class,
				() -> authenticationController.login(user));

		assertEquals("Invalid Username or password", exception.getMessage());
	}

	@Test
	void testValidToken() {
		UserLogin user = new UserLogin("user1", "user1");
		UserDetails userDetails = new User(user.getUserName(), user.getPassword(), new ArrayList<>());

		when(jwtUtil.validateToken("token", userDetails)).thenReturn(true);
		when(jwtUtil.extractUsername("token")).thenReturn("user1");
		when(userService.loadUserByUsername("user1")).thenReturn(userDetails);

		ResponseEntity<?> validity = authenticationController.getValidity("Bearer token");
		assertTrue(validity.getBody().toString().contains("true"));
	}

	@Test
	void testInvalidToken() {
		UserLogin user = new UserLogin("user1", "user1");
		UserDetails userDetails = new User(user.getUserName(), user.getPassword(), new ArrayList<>());

		when(jwtUtil.validateToken("token", userDetails)).thenReturn(false);
		when(jwtUtil.extractUsername("token")).thenReturn("user1");
		when(userService.loadUserByUsername("user1")).thenReturn(userDetails);

		ResponseEntity<?> validity = authenticationController.getValidity("Bearer token");
		assertEquals(true, validity.getBody().toString().contains("false"));
	}
	
	@Test
	void testInvalidTokenWhenSignatureInvalid() {
		UserLogin user = new UserLogin("user1", "user1");
		UserDetails userDetails = new User(user.getUserName(), user.getPassword(), new ArrayList<>());

		when(jwtUtil.validateToken("token", userDetails)).thenThrow(SignatureException.class);
		when(jwtUtil.extractUsername("token")).thenReturn("user1");
		when(userService.loadUserByUsername("user1")).thenReturn(userDetails);

		ResponseEntity<?> validity = authenticationController.getValidity("Bearer token");
		assertEquals(true, validity.getBody().toString().contains("false"));
	}
}
