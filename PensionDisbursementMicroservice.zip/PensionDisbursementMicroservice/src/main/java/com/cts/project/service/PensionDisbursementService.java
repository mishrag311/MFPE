package com.cts.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.project.exception.TokenInvalidException;
import com.cts.project.model.PensionerDetail;
import com.cts.project.model.ProcessPensionInput;
import com.cts.project.restclients.AuthServiceProxy;
import com.cts.project.restclients.PensionerDetailClient;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PensionDisbursementService {

	@Autowired
	private PensionerDetailClient pensionerDetailClient;

	@Autowired
	private AuthServiceProxy authServiceProxy;

	private static final int SUCCESS = 10;
	private static final int ERROR = 21;
	private static final String PUBLIC = "PUBLIC";
	private static final String PRIVATE = "PRIVATE";

	public Integer getPensionDisbursement(String token, ProcessPensionInput processPensionInput)
			throws TokenInvalidException {
		log.info("BEGIN - [getPensionDisbursement()]");
		try {
			if (!authServiceProxy.validateToken(token)) {
				throw new TokenInvalidException("Token is Invalid");
			}
		} catch (FeignException e) {
			throw new TokenInvalidException("Token is Invalid or Expired");
		}

		PensionerDetail pensionDetail = null;
		pensionDetail = getPensionDetail(token, processPensionInput.getAadharNumber());
		if (pensionDetail == null)
			return ERROR;
		String bankType = pensionDetail.getBankDetail().getBankType();
		Double bankCharge = processPensionInput.getBankCharge();

		if (validateBankCharge(bankType.toUpperCase(), bankCharge)
				&& validatePension(pensionDetail, processPensionInput.getPensionAmount())) {
			return SUCCESS;
		}
		log.info("END - [getPensionDisbursement()]");
		return ERROR;
	}

	public PensionerDetail getPensionDetail(String token, String aadharNumber) {
		log.info("BEGIN - [getPensionDetail()]");
		PensionerDetail pensionerDetail = pensionerDetailClient.getPensionerDetails(token, aadharNumber);
		log.debug("Pensioner Detaik :=" + pensionerDetail);
		log.info("END - [getPensionDetail()]");
		return pensionerDetail;
	}

	public boolean validatePension(PensionerDetail pensionerDetail, double calculatedPension) {
		double pensionAmount = 0;
		log.info("BEGIN - [validatePension()]");
		if (pensionerDetail.getPensionType().equalsIgnoreCase("self")) {
			pensionAmount = 0.8 * pensionerDetail.getSalaryEarned() + pensionerDetail.getAllowances();
		} else if (pensionerDetail.getPensionType().equalsIgnoreCase("family")) {
			pensionAmount = 0.5 * pensionerDetail.getSalaryEarned() + pensionerDetail.getAllowances();
		}
		log.debug("Pension Amount :=" + pensionAmount);
		log.info("END - [validatePension()]");
		return pensionAmount == calculatedPension;
	}

	public boolean validateBankCharge(String bankType, Double bankCharge) {
		log.info("BEGIN - [validateBankCharge()]");
		switch (bankType) {
		case PRIVATE:
			if (bankCharge == 550)
				return true;// Pension disbursement Success
			else if (bankCharge == 0)
				return false;// Bank service charge not paid now it should pe paid
			break;
		case PUBLIC:
			if (bankCharge == 500)
				return true;// Pension disbursement Success
			else if (bankCharge == 0)
				return false;// Bank service charge not paid
			break;
		default:
			return false;// Bank service charge less or greater than required
		}
		log.info("END - [validateBankCharge()]");
		return false;
	}
}