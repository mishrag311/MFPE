package com.cts.project.processpensionmicroservice.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@ApiModel(description = "Model class for Pensioner Input")
public class PensionerInput {

	@ApiModelProperty(value = "Name of the Pensioner")
	private String name;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@ApiModelProperty(value = "Date of birth of the Pensioner")
	private LocalDate dateOfBirth;

	@ApiModelProperty(value = "PAN number of the Pensioner")
	private String pan;

	@ApiModelProperty(value = "Aadhar number of the Pensioner")
	private String aadharNumber;

	@ApiModelProperty(value = "Type of pension self/family")
	private String pensionType;

}
