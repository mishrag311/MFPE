package com.cts.project.processpensionmicroservice.util;

import com.cts.project.processpensionmicroservice.model.PensionerDetail;
import com.cts.project.processpensionmicroservice.model.PensionerInput;

public class ValidatePensionerDetails {

	private ValidatePensionerDetails() {
		super();
	}

	public static boolean isValidDetails(PensionerInput pensionerInput, PensionerDetail pensionerDetail) {
		return (pensionerDetail.getPensionerName().equalsIgnoreCase(pensionerInput.getName())
				&& pensionerDetail.getPensionerDob().equals(pensionerInput.getDateOfBirth())
				&& pensionerDetail.getPensionerPAN().equalsIgnoreCase(pensionerInput.getPan())
				&& pensionerDetail.getPensionType().equalsIgnoreCase(pensionerInput.getPensionType()));
	}
}
