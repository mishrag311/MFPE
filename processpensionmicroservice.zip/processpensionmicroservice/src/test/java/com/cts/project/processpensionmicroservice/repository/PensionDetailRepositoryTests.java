package com.cts.project.processpensionmicroservice.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.DirtiesContext;

import com.cts.project.processpensionmicroservice.model.PensionDetail;

@DataJpaTest
class PensionDetailRepositoryTests {

	@Autowired
	private TestEntityManager entityManager;

	@Autowired
	private PensionDetailRepository pensionDetailRepository;

	@Test
	@DirtiesContext
	void testRepositoryIsEmpty() {
		Iterable<PensionDetail> pensionDetails = pensionDetailRepository.findAll();

		assertThat(pensionDetails).isEmpty();
	}

	@Test
	@DirtiesContext
	void testSavePensionDetail() {
		PensionDetail pensionDetail = pensionDetailRepository
				.save(new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBJP1234", "self", 10000));

		assertThat(pensionDetail).hasFieldOrPropertyWithValue("id", 1L)
			.hasFieldOrPropertyWithValue("name", "Shivam")
			.hasFieldOrPropertyWithValue("dateOfBirth", LocalDate.of(1998, 8, 3))
			.hasFieldOrPropertyWithValue("pan", "FBJP1234")
			.hasFieldOrPropertyWithValue("pensionType", "self")
			.hasFieldOrPropertyWithValue("pensionAmount", 10000.0);
	}

	@Test
	@DirtiesContext
	void testFindAllPensionDetails() {
		entityManager.persist(new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBJP1234", "self", 10000));
		entityManager.persist(new PensionDetail("Sam", LocalDate.of(1997, 5, 13), "GHDK1234", "family", 20000));
		entityManager.persist(new PensionDetail("Jon", LocalDate.of(1996, 12, 30), "UIFH1234", "self", 30000));

		Iterable<PensionDetail> pensionDetails = pensionDetailRepository.findAll();
		assertThat(pensionDetails).hasSize(3);
	}

	@Test
	@DirtiesContext
	void testFindPensionDetailById() {
		PensionDetail pensionDetail = new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBJP1234", "self", 10000);
		entityManager.persist(pensionDetail);

		PensionDetail foundPensionDetail = pensionDetailRepository.findById(pensionDetail.getId()).get();
		assertThat(foundPensionDetail).isEqualTo(pensionDetail);
	}

	@Test
	@DirtiesContext
	void testDeletePensionDetailById() {
		entityManager.persist(new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBJP1234", "self", 10000));
		entityManager.persist(new PensionDetail("Sam", LocalDate.of(1997, 5, 13), "GHDK1234", "family", 20000));
		entityManager.persist(new PensionDetail("Jon", LocalDate.of(1996, 12, 30), "UIFH1234", "self", 30000));

		pensionDetailRepository.deleteById(1L);

		Iterable<PensionDetail> pensionDetails = pensionDetailRepository.findAll();
		assertThat(pensionDetails).hasSize(2);
	}

	@Test
	@DirtiesContext
	void testDeleteAll() {
		entityManager.persist(new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBJP1234", "self", 10000));
		entityManager.persist(new PensionDetail("Sam", LocalDate.of(1997, 5, 13), "GHDK1234", "family", 20000));

		pensionDetailRepository.deleteAll();
		assertThat(pensionDetailRepository.findAll()).isEmpty();
	}

}
