package com.cts.project.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class ProcessPensionInputTest {

	@Test
	void testProcessPensionInputBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(ProcessPensionInput.class);
	}

	@Test
	void testBankDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(BankDetail.class);
	}

	@Test
	void testProcessPensionerResponse() {
		ProcessPensionResponse ppR = new ProcessPensionResponse(10);
		assertEquals(10, ppR.getProcessPensionStatusCode());
	}

	@Test
	void testPensionerDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(PensionerDetail.class);
	}

	@Test
	void testProcessPensionResponseBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(ProcessPensionResponse.class);
	}

	@Test
	void testPensionerBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(ProcessPensionInput.class);
	}

	@Test
	void testPensionerDetailAllArgsConstructor() {
		BankDetail bankDetail = new BankDetail("ICICI", "ICIC012345", "Private");
		PensionerDetail pensionerDetail = new PensionerDetail("0123456897", "Gaurav", LocalDate.now(), "ABX123456",
				30000, 50000, "Self", bankDetail);
		assertEquals("Gaurav", pensionerDetail.getPensionerName());
	}

}
