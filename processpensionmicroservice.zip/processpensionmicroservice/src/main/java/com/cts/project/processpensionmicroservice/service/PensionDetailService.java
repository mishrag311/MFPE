package com.cts.project.processpensionmicroservice.service;

import com.cts.project.processpensionmicroservice.model.PensionDetail;

public interface PensionDetailService {
	
	public PensionDetail save(PensionDetail pensionDetail);

}
