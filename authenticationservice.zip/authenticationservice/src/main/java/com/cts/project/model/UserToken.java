package com.cts.project.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@ApiModel(description = "Model class for User Token")
public class UserToken {
	@ApiModelProperty(value = "Username of the Pensioner")
	private String userName;

	@ApiModelProperty(value = "Authorization token of the User")
	private String authToken;

}
