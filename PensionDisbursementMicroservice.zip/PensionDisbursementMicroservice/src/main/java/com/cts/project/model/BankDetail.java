package com.cts.project.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ApiModel(description = "Model class for Bank Details")
public class BankDetail {

	@ApiModelProperty(value = "Name of the Bank")
	private String bankName;

	@ApiModelProperty(value = "Account Number of the Customer")
	private String accountNumber;

	@ApiModelProperty(value = "Customer Account Type")
	private String bankType;
}
