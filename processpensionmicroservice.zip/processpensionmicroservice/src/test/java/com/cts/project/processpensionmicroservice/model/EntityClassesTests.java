package com.cts.project.processpensionmicroservice.model;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

import nl.jqno.equalsverifier.EqualsVerifier;

class EntityClassesTests {

	@Test
	void testPensionDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(PensionDetail.class);
	}

	@Test
	void testPensionerDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(PensionerDetail.class);
	}

//	@Test 
//	void testPensionerDetailEqualsAndHashCode() {
//		EqualsVerifier.simple().forClass(PensionerDetail.class).verify();
//	}

	@Test
	void testPensionerInputBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(PensionerInput.class);
	}

	@Test
	void testPensionerInputEqualsAndHashCode() {
		EqualsVerifier.simple().forClass(PensionerInput.class).verify();
	}

	@Test
	void testProcessPensionInputBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(ProcessPensionInput.class);
	}

//	@Test 
//	void testProcessPensionInputEqualsAndHashCode() {
//		EqualsVerifier.simple().forClass(ProcessPensionInput.class).verify();
//	}

	@Test
	void testBankDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(BankDetail.class);
	}

//	@Test 
//	void testBankEqualsAndHashCode() {
//		EqualsVerifier.simple().forClass(BankDetail.class).verify();
//	}

	@Test
	void testBankBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(Bank.class);
	}
}
