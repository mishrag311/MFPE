package com.cts.project.processpensionmicroservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.project.processpensionmicroservice.model.PensionDetail;

public interface PensionDetailRepository extends JpaRepository<PensionDetail, Long> {

}
