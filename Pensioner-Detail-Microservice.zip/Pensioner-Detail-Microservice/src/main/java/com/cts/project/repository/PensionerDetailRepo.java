package com.cts.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.project.model.PensionerDetail;

public interface PensionerDetailRepo extends JpaRepository<PensionerDetail, String> {

}
