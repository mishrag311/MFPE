package com.cts.project.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;
import org.mockito.Mock;

import nl.jqno.equalsverifier.EqualsVerifier;

class ModelTest {

	@Mock
	UserLogin myUser;

	@Test
	void testUserLoginBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(UserLogin.class);
	}


	@Test
	void testUserTokenBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(UserToken.class);
	}

	@Test
	void testUserTokenEqualsAndHashCode2() {
		EqualsVerifier.simple().forClass(UserToken.class).verify();
	}

	@Test
	void testUserLoginAllArgs() {
		UserLogin userLogin = new UserLogin("gaurav", "dummy");
		assertEquals("gaurav", userLogin.getUserName());
		assertEquals("dummy", userLogin.getPassword());
	}

	@Test
	void testUserTokenAllArgs() {
		UserToken userToken = new UserToken("gaurav", "token");
		assertEquals("gaurav", userToken.getUserName());
		assertEquals("token", userToken.getAuthToken());
	}

//	@Test
//	void testEqualsMethod() {
//		myUser = new UserLogin();
//		myUser.setUserName("saivi");
//		myUser.setPassword("abc");
//		boolean equals = myUser.equals(myUser);
//		assertTrue(equals);
//	}
//
//	@Test
//	void testHashCodeMethod() {
//		myUser = new UserLogin();
//		myUser.setUserName("saivi");
//		myUser.setPassword("abc");
//		int hashCode = myUser.hashCode();
//		assertEquals(hashCode, myUser.hashCode());
//	}

}
