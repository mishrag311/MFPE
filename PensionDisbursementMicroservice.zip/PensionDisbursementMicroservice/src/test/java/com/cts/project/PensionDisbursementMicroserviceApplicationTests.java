package com.cts.project;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PensiondisbursementApplicationTests {

	@Test
	void applicationStarts() {
		PensionDisbursementMicroserviceApplication.main(new String[] {});
		assertTrue(true);
	}
}
