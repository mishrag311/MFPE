package com.cts.project.processpensionmicroservice.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.project.processpensionmicroservice.model.PensionerDetail;

@FeignClient(name = "pensioner-detail-service", url = "${pensionerdetail.feign.dns}")
public interface PensionerDetailMicroserviceProxy {

	@GetMapping("/{aadhaarNo}")
	public PensionerDetail fetchPensionerDetaiByAadhaar(@RequestHeader(name = "Authorization") String token,
			@PathVariable String aadhaarNo);

}
