package com.cts.project.processpensionmicroservice.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ApiModel(description = "Model class for Process Pension Input")
public class ProcessPensionInput {

	@ApiModelProperty(value = "Aadhar Number of the Pensioner")
	private String aadharNumber;
	
	@ApiModelProperty(value = "Total Pension amount")
	private double pensionAmount;
	
	@ApiModelProperty(value = "Bank Charge")
	private double bankCharge;
}
