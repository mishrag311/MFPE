package com.cts.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.project.exception.TokenInvalidException;
import com.cts.project.model.BankDetail;
import com.cts.project.model.PensionerDetail;
import com.cts.project.model.ProcessPensionInput;
import com.cts.project.restclients.AuthServiceProxy;
import com.cts.project.restclients.PensionerDetailClient;

@SpringBootTest
class PensionDisbursementServiceTest {

	@InjectMocks
	private PensionDisbursementService pensionDisbursementService;

	@Mock
	private PensionerDetailClient pensionerDetailClient;

	@Mock
	private AuthServiceProxy authServiceProxy;

	@Test
	void testGetPensionDetail() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Self",
				new BankDetail("Punjab National Bank", "9999689745", "Public"));
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, "546789641236")).thenReturn(pensionerDetail);
		assertEquals(pensionDisbursementService.getPensionDetail(token, "546789641236"), pensionerDetail);
	}

	@Test
	void testGetPensionDisbursementUnknownError() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Self",
				new BankDetail("Punjab National Bank", "9999689745", "Public"));
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 15600.0, 900.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementSuccess() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Self",
				new BankDetail("Punjab National Bank", "9999689745", "Public"));
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 15600.0, 500.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(10, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementPrivateBankFail() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Family",
				new BankDetail("Punjab National Bank", "9999689745", "Private"));
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 9200.0, 550.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementPrivateBankSuccess() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 16000.0, 1200.0, "Family",
				new BankDetail("Punjab National Bank", "9999689745", "Private"));
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 9200.0, 550.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(10, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementPrivateBankUnknownError() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Family",
				new BankDetail("Punjab National Bank", "9999689745", "Private"));
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 9200.0, 5250.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementUnknownErrorWrongBankType() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Family",
				new BankDetail("Punjab National Bank", "9999689745", "Wrongbank"));
		;
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 9200.0, 5250.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementWrongAadhar() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = null;
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 15600.0, 900.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementServiceChargeNotPaid() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Self",
				new BankDetail("Punjab National Bank", "9999689745", "Public"));

		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 15600.0, 0.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementPrivateBankChargeNotPaid() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Family",
				new BankDetail("Punjab National Bank", "9999689745", "Private"));
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 9200.0, 0.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

	@Test
	void testGetPensionDisbursementWrongPensionType() throws TokenInvalidException {
		String token = "dummyToken";
		PensionerDetail pensionerDetail = new PensionerDetail("546789641236", "Rashmi Ranjan",
				LocalDate.of(1974, Month.AUGUST, 15), "AAA12569CC", 18000.0, 1200.0, "Failmy",
				new BankDetail("Punjab National Bank", "9999689745", "Public"));
		;
		ProcessPensionInput ppi = new ProcessPensionInput("546789641236", 9200.0, 5250.0);
		when(authServiceProxy.validateToken(token)).thenReturn(true);
		when(pensionerDetailClient.getPensionerDetails(token, ppi.getAadharNumber())).thenReturn(pensionerDetail);
		assertEquals(21, pensionDisbursementService.getPensionDisbursement(token, ppi));
	}

}
