package com.cts.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cts.project.exception.InvalidPensionerException;
import com.cts.project.exception.InvalidTokenException;
import com.cts.project.model.PensionerDetail;
import com.cts.project.service.PensionerDetailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Api(value = "Pensioner Detail resource REST endpoint")
public class PensionerDetailController {

	@Autowired
	private PensionerDetailService pensionerDetailService;

	@GetMapping({ "/{aadhaarNo}" })
	@ApiOperation(value = "checkPensionerAadhaar", notes = "returns pensionerDetail object conatining all the information available in database", httpMethod = "GET", response = PensionerDetail.class)
	public PensionerDetail fetchPensionerDetailByAadhaarFromDb(@RequestHeader(name = "Authorization") String token,
			@ApiParam(name = "aadhaarNo", value = "Aadhaar number of the Pensioner.") @PathVariable String aadhaarNo)
			throws InvalidPensionerException, InvalidTokenException {
		log.info("BEGIN   -   [fetchPensionerDetailByAadhaar()]");

		PensionerDetail pensionerDetail = pensionerDetailService.findAadhaar(token, aadhaarNo);
		log.debug("Pensioner Detail  := " + pensionerDetail);
		log.info("END   -   [fetchPensionerDetailByAadhaar()]");
		return pensionerDetail;
	}

	@GetMapping("/health-check")
	public ResponseEntity<String> healthCheck() {
		return new ResponseEntity<>("OK", HttpStatus.OK);
	}
}