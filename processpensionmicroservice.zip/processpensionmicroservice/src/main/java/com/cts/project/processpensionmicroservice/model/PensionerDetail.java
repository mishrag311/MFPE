package com.cts.project.processpensionmicroservice.model;

import java.time.LocalDate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ApiModel(description = "Model class for Pensioner Details")
public class PensionerDetail {
	
	@ApiModelProperty(value = "Aadhar Number of the Pensioner")
	private String aadhaarNumber;
	
	@ApiModelProperty(value = "Name of the Pensioner")
	private String pensionerName;
	
	@ApiModelProperty(value = "DOB of the Pensioner")
	private LocalDate pensionerDob;
	
	@ApiModelProperty(value = "PAN no. of the Pensioner")
	private String pensionerPAN;
	
	@ApiModelProperty(value = "Salary Earned by the Pensioner")
	private double salaryEarned;
	
	@ApiModelProperty(value = "Allowances of the Pensioner")
	private double allowances;
	
	@ApiModelProperty(value = "Type of pension self/family")
	private String pensionType;
	
	@ApiModelProperty(value = "Bank Details of the Pensioner")
	private BankDetail bankDetail;
	
	
}
