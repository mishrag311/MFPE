package com.cts.project.model;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class BankDetailTest {

	@Test
	void testBankeDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(BankDetail.class);
	}

}
