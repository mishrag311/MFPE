package com.cts.training.webclient.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.training.webclient.feign.PensionClient;
import com.cts.training.webclient.model.PensionDetail;
import com.cts.training.webclient.model.PensionerInput;
import com.cts.training.webclient.model.ProcessPensionInput;
import com.cts.training.webclient.service.TokenCheckService;

import feign.FeignException;

@Controller
public class PensionController {

	@Autowired
	private PensionClient pensionClient;

	@Autowired
	private TokenCheckService tokenCheck;

	@GetMapping("/details")
	public ModelAndView index(HttpServletRequest request) {
		if (tokenCheck.checkStatus(request) == null) {
			ModelAndView model = new ModelAndView("details");
			model.addObject(new PensionerInput());
			return model;
		}
		return tokenCheck.checkStatus(request);
	}

	@PostMapping("/index")
	public ModelAndView showForm(@Valid @ModelAttribute("pensionerInput") PensionerInput pensionerInput,
			final BindingResult result, HttpServletRequest request) {

		if (result.hasErrors()) {
			return new ModelAndView("index");
		}

		if (tokenCheck.checkStatus(request) == null) {
			String token = request.getSession().getAttribute("token").toString();
			ModelAndView model = new ModelAndView("details");
			PensionDetail pensionerDetail = null;
			try {
				pensionerDetail = pensionClient.getPensionDetail(token, pensionerInput);
			} catch (FeignException.BadRequest e) {
				model.setViewName("index");
				model.addObject("detailsAlreadyExist", "Entered details are incorrect");
				return model;
			} catch (FeignException.NotFound e) {
				model.setViewName("index");
				model.addObject("invalidDetails", "Aadhar Entered is incorrect");
				return model;
			}
			model.addObject("pensionerDetail", pensionerDetail);
			return model;
		}
		return tokenCheck.checkStatus(request);

	}

	@GetMapping("/disburse")
	public ModelAndView processPensionInput(
			@ModelAttribute("processPensionInput") ProcessPensionInput processPensionInput, final BindingResult result,
			HttpServletRequest request) {
		if (tokenCheck.checkStatus(request) == null) {
			ModelAndView model = new ModelAndView("disburse");
			model.addObject("processPensionInput", processPensionInput);
			return model;
		}
		return tokenCheck.checkStatus(request);
	}

	@PostMapping("/disburse")
	public ModelAndView disburseProcess(@Valid @ModelAttribute("processPensionInput") ProcessPensionInput processPensionInput,
			final BindingResult result, HttpServletRequest request) {
		if (result.hasErrors()) {
			return new ModelAndView("disburse");
		}
		if (tokenCheck.checkStatus(request) == null) {
			String token = request.getSession().getAttribute("token").toString();
			Integer code = null;
			try {
				code = pensionClient.processPension(token, processPensionInput);
			} catch (FeignException e) {
				ModelAndView model = new ModelAndView("disburse");
				model.addObject("invalidAadhar", "Enter a valid Aadhar Number");
				return model;
			}
			try {
				if (code == 10) {
					return new ModelAndView("success");
				}
				return new ModelAndView("fail");
			} catch (Exception e) {
				return new ModelAndView("error");
			}

		}
		return tokenCheck.checkStatus(request);
	}
	
	@GetMapping("/about")
	public ModelAndView aboutUs() {
		return new ModelAndView("about");
	}
}
