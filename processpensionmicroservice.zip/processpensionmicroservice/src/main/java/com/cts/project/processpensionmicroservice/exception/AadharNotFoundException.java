package com.cts.project.processpensionmicroservice.exception;

public class AadharNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8094620206245086228L;
	
	public AadharNotFoundException(String msg) {
		super(msg);
	}
}
