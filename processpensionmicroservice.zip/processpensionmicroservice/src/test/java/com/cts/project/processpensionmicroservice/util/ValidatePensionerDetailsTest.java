package com.cts.project.processpensionmicroservice.util;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.cts.project.processpensionmicroservice.model.BankDetail;
import com.cts.project.processpensionmicroservice.model.PensionerDetail;
import com.cts.project.processpensionmicroservice.model.PensionerInput;

class ValidatePensionerDetailsTest {

	@Test
	void testValidDetails() {
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.now(), "FBCJ1022", "1234567891234567",
				"self");
		PensionerDetail pensionerDetail = new PensionerDetail("1324324234", "Shivam", LocalDate.now(), "FBCJ1022",
				100000, 20000, "self", new BankDetail());
		assertTrue(ValidatePensionerDetails.isValidDetails(pensionerInput, pensionerDetail));
	}

	@Test
	void testInvalidValidName() {
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.now(), "FBCJ1022", "1234567891234567",
				"self");
		PensionerDetail pensionerDetail = new PensionerDetail("1324324234", "Sam", LocalDate.now(), "FBCJ1022", 100000,
				20000, "self", new BankDetail());
		assertFalse(ValidatePensionerDetails.isValidDetails(pensionerInput, pensionerDetail));
	}

	@Test
	void testInvalidValidDateOfBirth() {
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.now(), "FBCJ1022", "1234567891234567",
				"self");
		PensionerDetail pensionerDetail = new PensionerDetail("1324324234", "Shivam", LocalDate.of(2020, 8, 12),
				"FBCJ1022", 100000, 20000, "self", new BankDetail());
		assertFalse(ValidatePensionerDetails.isValidDetails(pensionerInput, pensionerDetail));
	}

	@Test
	void testInvalidPan() {
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.now(), "FBCJ1022", "1234567891234567",
				"self");
		PensionerDetail pensionerDetail = new PensionerDetail("1324324234", "Shivam", LocalDate.now(), "FBZJ1022",
				100000, 20000, "self", new BankDetail());
		assertFalse(ValidatePensionerDetails.isValidDetails(pensionerInput, pensionerDetail));
	}

	@Test
	void testInvalidPensionType() {
		PensionerInput pensionerInput = new PensionerInput("Shivam", LocalDate.now(), "FBCJ1022", "1234567891234567",
				"self");
		PensionerDetail pensionerDetail = new PensionerDetail("1324324234", "Shivam", LocalDate.now(), "FBCJ1022",
				100000, 20000, "family", new BankDetail());
		assertFalse(ValidatePensionerDetails.isValidDetails(pensionerInput, pensionerDetail));
	}
}
