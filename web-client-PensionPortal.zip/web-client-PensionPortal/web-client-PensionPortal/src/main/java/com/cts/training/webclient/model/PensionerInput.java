package com.cts.training.webclient.model;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString

public class PensionerInput {

	@Pattern(regexp = "[a-zA-Z ]+", message = "Please enter valid Name")
	@NotEmpty(message = "Name cannot be Empty")
	private String name;

	@Past
	@NotNull(message = "Date of Birth cannot be Null")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateOfBirth;

	@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Please enter valid Pan number")
	@NotEmpty(message = "Pan cannot be null")
	private String pan;

	@NotEmpty(message = "Aadhar number cannot be Empty")
	@Pattern(regexp = "UI[0-9]{9}DAI", message = "Please enter a valid Aadhar number")
	private String aadharNumber;

	@NotEmpty(message = "Pension Type cannot be Empty")
	private String pensionType;
}
