package com.cts.project.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.cts.project.model.UserLogin;
import com.cts.project.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService implements UserDetailsService {

	@Autowired
	UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) {
		log.info("BEGIN   -   [loadUserByUsername()]");
		log.debug("Username : " + username);

		UserLogin userLogin = userRepository.findById(username).orElseThrow();
		log.debug("UserLogin : " + userLogin);
		UserDetails user = new User(userLogin.getUserName(), userLogin.getPassword(), new ArrayList<>());
		log.debug("User : " + user);

		log.info("END   -   [loadUserByUsername()]");
		return user;
	}

}
