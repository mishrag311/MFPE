package com.cts.training.webclient.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class ProcessPensionInput {

	@NotEmpty(message = "Aadhar number cannot be Empty")
	private String aadharNumber;

	@NotNull(message = "Pension Amount cannot be Empty")
	private double pensionAmount;

	private double bankCharge;
}
