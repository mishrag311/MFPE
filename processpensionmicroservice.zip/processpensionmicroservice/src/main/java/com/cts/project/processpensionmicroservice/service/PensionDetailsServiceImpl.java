package com.cts.project.processpensionmicroservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.project.processpensionmicroservice.model.PensionDetail;
import com.cts.project.processpensionmicroservice.repository.PensionDetailRepository;

@Service
public class PensionDetailsServiceImpl implements PensionDetailService {
	
	@Autowired
	private PensionDetailRepository pensionDetailRepository;

	@Override
	public PensionDetail save(PensionDetail pensionDetail) {
		return pensionDetailRepository.save(pensionDetail);
	}

}
