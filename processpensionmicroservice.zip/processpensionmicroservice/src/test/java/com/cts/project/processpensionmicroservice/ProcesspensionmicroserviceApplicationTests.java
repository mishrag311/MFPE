package com.cts.project.processpensionmicroservice;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ProcesspensionmicroserviceApplicationTests {

	@Test
	void applicationStarts() {
		ProcesspensionmicroserviceApplication.main(new String[] {});
		assertTrue(true);
	}

}
