package com.cts.project.processpensionmicroservice.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
@ApiModel(description = "Model class for Pension Details")
public class PensionDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@ApiModelProperty(value = "Id of the Pensioner")
	private Long id;

	@ApiModelProperty(value = "Name of the Pensioner")
	private String name;

	@ApiModelProperty(value = "Date of birth of the Pensioner")
	private LocalDate dateOfBirth;

	@Column(unique = true)
	@ApiModelProperty(value = "PAN number of the Pensioner")
	private String pan;

	@ApiModelProperty(value = "Type of pension self/family")
	private String pensionType;

	@ApiModelProperty(value = "Total Pension")
	private double pensionAmount;

	public PensionDetail(String name, LocalDate dateOfBirth, String pan, String pensionType, double pensionAmount) {
		super();
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.pan = pan;
		this.pensionType = pensionType;
		this.pensionAmount = pensionAmount;
	}

}
