package com.cts.training.webclient.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.cts.training.webclient.feign.AuthenticationClient;
import com.cts.training.webclient.model.PensionerInput;
import com.cts.training.webclient.model.UserLogin;
import com.cts.training.webclient.model.UserToken;
import com.cts.training.webclient.service.TokenCheckServiceImpl;

import lombok.extern.slf4j.Slf4j;


@Controller
@Slf4j
public class LoginController {
	
	@Autowired
	private AuthenticationClient authenticationClient;
	
	@Autowired
	private TokenCheckServiceImpl tokenCheckService;

	@GetMapping("/login")
	public String loginPage(Model model) {
		model.addAttribute("credentials", new UserLogin());
		return "login";
	}

	@PostMapping("/login")
	public ModelAndView afterLogin(@ModelAttribute("credentials") UserLogin credentials, HttpServletRequest request) {
		log.info("BEGIN   -   [afterLogin()]");
		UserToken token = null;
		try {
			token = authenticationClient.login(credentials);
			log.debug("Recieved Token Successfully");
		} catch(Exception e) {
			log.debug("Invalid Credentials : " + credentials);
			return new ModelAndView(new RedirectView("loginerror"));
		}
		request.getSession().setAttribute("token", "Bearer " + token.getAuthToken());
		request.getSession().setAttribute("userName", credentials.getUserName());
		log.info("END   -   [afterLogin()]");
		return new ModelAndView(new RedirectView("index"));
	}
	
	@GetMapping("/logout")
	public ModelAndView logout(HttpServletRequest request) {
		request.getSession().setAttribute("token", null);
		request.getSession().setAttribute("userName", null);
		ModelAndView model = new ModelAndView("login");
		model.addObject("credentials", new UserLogin());
		model.addObject("logoutMessage", "You have been logged out successfully");
		return model;
	}
	
	@GetMapping("/loginerror")
	public ModelAndView loginError() {
		ModelAndView model = new ModelAndView("login");
		model.addObject("credentials", new UserLogin());
		model.addObject("credentialsInvalid", "Invalid Username or password");
		return model;
	}
	
	@GetMapping("session-expired")
	public ModelAndView sessionExpired() {
		ModelAndView model = new ModelAndView("login");
		model.addObject("credentials", new UserLogin());
		model.addObject("sessionExpired", "Session has Expired. Please login again");
		return model;
	}
	
	@GetMapping({"/index", "", "/"})
	public ModelAndView getIndex(HttpServletRequest request) {
		log.info("BEGIN   -   [getIndex()]");
		if (tokenCheckService.checkStatus(request) == null) {
			ModelAndView model = new ModelAndView("index");
			model.addObject("pensionerInput", new PensionerInput());
			return model;
		} 
		log.info("BEGIN   -   [getIndex()]");
		return tokenCheckService.checkStatus(request);
	}

}