package com.cts.project.service;

import org.springframework.stereotype.Service;

import com.cts.project.exception.InvalidPensionerException;
import com.cts.project.exception.InvalidTokenException;
import com.cts.project.model.PensionerDetail;

@Service
public interface PensionerDetailService {

	public PensionerDetail findAadhaar(String token, String aadhaarNo)
			throws InvalidPensionerException, InvalidTokenException;

}
