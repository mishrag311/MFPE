package com.cts.project.processpensionmicroservice.service;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.cts.project.processpensionmicroservice.model.PensionDetail;
import com.cts.project.processpensionmicroservice.repository.PensionDetailRepository;

@SpringBootTest
class PensionDetailsServiceImplTests {

	@InjectMocks
	private PensionDetailsServiceImpl pensionDetailsServiceImpl;

	@Mock
	private PensionDetailRepository pensionDetailRepository;

	@Test
	@DirtiesContext
	void testCreatePensionDetail() {
		PensionDetail pensionDetail = new PensionDetail("Shivam", LocalDate.of(1998, 8, 3), "FBJP1234", "self", 10000);
		pensionDetailsServiceImpl.save(pensionDetail);
		verify(pensionDetailRepository, times(1)).save(pensionDetail);
	}

}
