package com.cts.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cts.project.exception.CredentialsException;
import com.cts.project.model.UserLogin;
import com.cts.project.model.UserToken;
import com.cts.project.service.JwtUtil;
import com.cts.project.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Api(value = "Endpoints for Authentication Service")
public class AuthenticationController {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private UserService userService;

	@PostMapping("/login")
	@ApiOperation(value = "userLogin", notes = "tokes user credentials and generate a JWT", httpMethod = "POST", response = ResponseEntity.class)
	public ResponseEntity<Object> login(
			@ApiParam(name = "userloginCredentials", value = "Login credentials of the User.") @RequestBody UserLogin userLoginCredentials)
			throws CredentialsException {
		log.info("BEGIN   -   [login(userLoginCredentials)]");
		final UserDetails userdetails = userService.loadUserByUsername(userLoginCredentials.getUserName());
		log.debug("{}", userdetails);
		if (userdetails.getPassword().equals(userLoginCredentials.getPassword())) {
			log.info("END  -   [login(userLoginCredentials)]");
			return new ResponseEntity<>(
					new UserToken(userLoginCredentials.getUserName(), jwtUtil.generateToken(userdetails)),
					HttpStatus.OK);
		} else {
			log.info("END  -   [login(userLoginCredentials)]");
			throw new CredentialsException("Invalid Username or password");
		}

	}

	@GetMapping("/validate")
	@ApiOperation(value = "tokenValidation", notes = "returns boolean after validating JWT", httpMethod = "GET", response = ResponseEntity.class)
	public ResponseEntity<Object> getValidity(
			@ApiParam(name = "token", value = "JWT for current user") @RequestHeader(name = "Authorization") String token1) {
		log.info("BEGIN   -   [getValidty(token)]");
		String token = token1.substring(7);

		try {
			UserDetails user = userService.loadUserByUsername(jwtUtil.extractUsername(token));
			if (Boolean.TRUE.equals(jwtUtil.validateToken(token, user))) {
				log.debug("Valid token");
				log.info("{END} : validate()");
				return new ResponseEntity<>(true, HttpStatus.OK);
			} else {
				log.debug("Invalid token");
				log.info("{END} : getValidity()");
				return new ResponseEntity<>(false, HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			log.debug("Invalid token");
			log.info("{END} : getValidity()");
			return new ResponseEntity<>(false, HttpStatus.FORBIDDEN);
		}
	}

	@GetMapping("/health-check")
	public ResponseEntity<String> healthCheck() {
		return new ResponseEntity<>("OK", HttpStatus.OK);
	}

}
