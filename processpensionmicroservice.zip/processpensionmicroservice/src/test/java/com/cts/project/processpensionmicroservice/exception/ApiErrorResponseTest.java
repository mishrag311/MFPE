package com.cts.project.processpensionmicroservice.exception;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;


class ApiErrorResponseTest {

	@Test
	void testPensionDetailBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDateTime.class, new LocalDateTimeFactory());
		beanTester.testBean(ApiErrorResponse.class);
	}
}
