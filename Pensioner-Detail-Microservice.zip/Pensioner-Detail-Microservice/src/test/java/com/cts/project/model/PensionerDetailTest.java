package com.cts.project.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class PensionerDetailTest {

	@Test
	void testPensionerBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(PensionerDetail.class);
	}

	@Test
	void testPensionerDetailAllArgsConstructor() {
		BankDetail bankDetail = new BankDetail("ICICI", "ICIC012345", "Private");
		PensionerDetail pensionerDetail = new PensionerDetail("0123456897", "Gaurav", LocalDate.now(), "ABX123456",
				30000, 50000, "Self", bankDetail);
		assertEquals("Gaurav", pensionerDetail.getPensionerName());
	}

}
