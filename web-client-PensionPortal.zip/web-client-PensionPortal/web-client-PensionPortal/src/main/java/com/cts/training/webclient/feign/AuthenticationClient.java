package com.cts.training.webclient.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.training.webclient.model.UserLogin;
import com.cts.training.webclient.model.UserToken;

@FeignClient(name = "authentication-service", url = "${auth.feign.dns}")
public interface AuthenticationClient {

	@PostMapping("/login")
	public UserToken login(@RequestBody UserLogin userlogincredentials);

	@GetMapping("/validate")
	public boolean validateToken(@RequestHeader(name = "Authorization", required = true) String token);
}
