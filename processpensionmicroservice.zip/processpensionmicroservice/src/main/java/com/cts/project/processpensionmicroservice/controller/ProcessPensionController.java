package com.cts.project.processpensionmicroservice.controller;

import com.cts.project.processpensionmicroservice.exception.AadharNotFoundException;
import com.cts.project.processpensionmicroservice.exception.InvalidDetailsEnteredException;
import com.cts.project.processpensionmicroservice.exception.InvalidTokenException;
import com.cts.project.processpensionmicroservice.model.PensionDetail;
import com.cts.project.processpensionmicroservice.model.PensionerInput;
import com.cts.project.processpensionmicroservice.model.ProcessPensionInput;
import com.cts.project.processpensionmicroservice.service.PensionDetailsServiceImpl;
import com.cts.project.processpensionmicroservice.service.ProcessPensionServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Api(value = "Process Pension Controller REST endpoint")
public class ProcessPensionController {

	@Autowired
	private PensionDetailsServiceImpl pensionDetailService;

	@Autowired
	private ProcessPensionServiceImpl processPensionService;

	@PostMapping("/PensionDetail")
	@ApiOperation(value = "getPensionDetails", notes = "Validates user details using PensionerDetail microservice and returns details of the user along with the calculated pension amount after", httpMethod = "POST", response = PensionDetail.class)
	public PensionDetail getPensionDetails(@RequestHeader(name = "Authorization") String token,
			@ApiParam(name = "pensionerInput", value = "Details of the Pensioner from UI") @RequestBody PensionerInput pensionerInput)
			throws InvalidDetailsEnteredException, InvalidTokenException, AadharNotFoundException {

		log.info("BEGIN   -   [getPensionDetails()]");

		PensionDetail pensionDetail = processPensionService.getPensionDetails(token, pensionerInput);
		log.debug("PensionDetail : " + pensionDetail);

		log.info("END   -   [getPensionDetails()]");

		return pensionDetailService.save(pensionDetail);
	}

	@PostMapping("/ProcessPension")
	@ApiOperation(value = "getPensionDetails", notes = "Invokes Pension disbursement microservice and returns the appropriate process code", httpMethod = "POST")
	public Integer processPension(@RequestHeader(name = "Authorization") String token,
			@ApiParam(name = "processPensionInput", value = "Aadhar and Pension Details of the Pensioner") @RequestBody ProcessPensionInput processPensionInput)
			throws InvalidTokenException {

		log.info("BEGIN   -   [processPension()]");
		log.info("END   -   [processPension()]");

		return processPensionService.getResponse(token, processPensionInput);
	}

	@GetMapping("/health-check")
	public ResponseEntity<String> healthCheck() {
		return new ResponseEntity<>("OK", HttpStatus.OK);
	}
}
