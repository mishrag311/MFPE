package com.cts.project.processpensionmicroservice.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.project.processpensionmicroservice.model.ProcessPensionInput;

@FeignClient(name = "pension-disbursement-service", url = "${pensionerdisbursement.feign.dns}")
public interface PensionDisbursementMicroservivceProxy {

	@PostMapping("/disbursepension")
	public Integer getPensionDisbursement(@RequestHeader(name = "Authorization") String token,
			@RequestBody ProcessPensionInput processPensionInput);

}
