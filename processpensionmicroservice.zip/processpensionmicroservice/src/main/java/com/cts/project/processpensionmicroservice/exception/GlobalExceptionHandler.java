package com.cts.project.processpensionmicroservice.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(InvalidDetailsEnteredException.class)
    protected ResponseEntity<ApiErrorResponse> handleInvalidDetailsEnteredException(InvalidDetailsEnteredException ex) {
        ApiErrorResponse errorResponse = new ApiErrorResponse(HttpStatus.BAD_REQUEST); 
        errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
        errorResponse.setMessage(ex.getMessage());
        return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(AadharNotFoundException.class)
    protected ResponseEntity<ApiErrorResponse> handleInvalidDetailsEnteredException(AadharNotFoundException ex) {
        ApiErrorResponse errorResponse = new ApiErrorResponse(HttpStatus.NOT_FOUND); 
        errorResponse.setLocalizedMessage(ex.getLocalizedMessage());
        errorResponse.setMessage(ex.getMessage());
        return new ResponseEntity<>(errorResponse,HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler(DataIntegrityViolationException.class)
    protected ResponseEntity<ApiErrorResponse> handleMultiplePanException(DataIntegrityViolationException ex) {
        ApiErrorResponse errorResponse = new ApiErrorResponse(HttpStatus.BAD_REQUEST); 
        errorResponse.setLocalizedMessage("Details already exist in the database");
        errorResponse.setMessage("Details already exist in the database");
        return new ResponseEntity<>(errorResponse,HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(InvalidTokenException.class)
    protected ResponseEntity<ApiErrorResponse> handleInvalidToken(InvalidTokenException ex) {
        ApiErrorResponse errorResponse = new ApiErrorResponse(HttpStatus.UNAUTHORIZED); 
        errorResponse.setLocalizedMessage("Token is invalid or expired");
        errorResponse.setMessage("Token is invalid or expired");
        return new ResponseEntity<>(errorResponse,HttpStatus.UNAUTHORIZED);
    }

    
}
