package com.cts.project.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
@ApiModel(description = "Model class for User Login")
public class UserLogin {

	@Id
	@ApiModelProperty(value = "Username of the Pensioner")
	private String userName;

	@ApiModelProperty(value = "Password of the Pensioner")
	private String password;

}
