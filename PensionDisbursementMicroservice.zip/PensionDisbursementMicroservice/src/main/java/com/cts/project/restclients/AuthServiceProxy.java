package com.cts.project.restclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.project.exception.TokenInvalidException;

@FeignClient(url = "${auth.feign.dns}", name = "process-pension-microservice")
public interface AuthServiceProxy {

	@GetMapping("/validate")
	public boolean validateToken(@RequestHeader(name = "Authorization", required = true) String token)
			throws TokenInvalidException;

}
