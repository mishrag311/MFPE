package com.cts.project;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationserviceApplicationTests {

	@Test
	void applicationStarts() throws IOException {
		AuthenticationserviceApplication.main(new String[] {});
		assertTrue(true);
	}

}
