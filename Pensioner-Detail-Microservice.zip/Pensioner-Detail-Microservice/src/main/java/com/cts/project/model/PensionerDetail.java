package com.cts.project.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "pensionerDetail")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ApiModel(description = "Model class for Pensioner Details")
public class PensionerDetail {

	@Id
	@ApiModelProperty(value = "Aadhaar Number of the Pensioner")
	private String aadhaarNumber;

	@ApiModelProperty(value = "Name of the Pensioner")
	private String pensionerName;

	@ApiModelProperty(value = "DOB of the Pensioner")
	private LocalDate pensionerDob;

	@ApiModelProperty(value = "PAN no. of the Pensioner")
	private String pensionerPAN;

	@ApiModelProperty(value = "Slary Earned by the Pensioner")
	private double salaryEarned;

	@ApiModelProperty(value = "Allowances of the Pensioner")
	private double allowances;

	@ApiModelProperty(value = "Type of Pension")
	private String pensionType;

	@OneToOne
	@ApiModelProperty(value = "Bank Details of the Pensioner")
	private BankDetail bankDetail;

}
