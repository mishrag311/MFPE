package com.cts.project.restclients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.project.model.PensionerDetail;

@FeignClient(name = "pensioner-detail-microservice", url = "${pensionerdetail.feign.dns}")
public interface PensionerDetailClient {

	@GetMapping("/{aadhaarNo}")
	PensionerDetail getPensionerDetails(@RequestHeader(name = "Authorization") String token,
			@PathVariable("aadhaarNo") String aadharNumber);

}