package com.cts.project.processpensionmicroservice.service;

import com.cts.project.processpensionmicroservice.exception.AadharNotFoundException;
import com.cts.project.processpensionmicroservice.exception.InvalidDetailsEnteredException;
import com.cts.project.processpensionmicroservice.exception.InvalidTokenException;
import com.cts.project.processpensionmicroservice.model.PensionDetail;
import com.cts.project.processpensionmicroservice.model.PensionerInput;
import com.cts.project.processpensionmicroservice.model.ProcessPensionInput;

public interface ProcessPensionService {

	public PensionDetail getPensionDetails(String token, PensionerInput pensionerInput)
			throws InvalidDetailsEnteredException, InvalidTokenException, AadharNotFoundException;
	
	public Integer getResponse(String token, ProcessPensionInput processPensionInput) throws InvalidTokenException;
}
