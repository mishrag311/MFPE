package com.cts.project.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.Month;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.cts.project.exception.InvalidPensionerException;
import com.cts.project.exception.InvalidTokenException;
import com.cts.project.model.BankDetail;
import com.cts.project.model.PensionerDetail;
import com.cts.project.proxy.AuthServiceProxy;
import com.cts.project.service.PensionerDetailDbServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
class PensionerDetailControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@InjectMocks
	private PensionerDetailController pensionerDetailController;

	@Mock
	private PensionerDetailDbServiceImpl pensionerService;

	@MockBean
	private AuthServiceProxy authProxy;

	@Test
	void contextLoads() throws Exception {
		assertThat(pensionerDetailController).isNotNull();
	}

	@Test
	void testPensionerDetailWhenAadhaarFound() throws Exception {
		String token = "dummy";
		when(authProxy.validateToken("Bearer " + token)).thenReturn(true);
		when(pensionerService.findAadhaar(token, "UI123456789DAI")).thenReturn(new PensionerDetail("", "Gaurav Mishra",
				LocalDate.of(1888, Month.APRIL, 1), "", 8552, 525, "", new BankDetail()));
		this.mockMvc.perform(get("/UI123456789DAI").header(HttpHeaders.AUTHORIZATION, "Bearer " + token))
				.andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(jsonPath("$.pensionerName").value("Gaurav Mishra"));
	}

	@Test
	void testPensionerDetailWithInvalidToken() throws Exception {
		String token = "dummy";
		when(authProxy.validateToken("Bearer " + token)).thenReturn(false);
		when(pensionerService.findAadhaar(token, "0123489")).thenThrow(InvalidTokenException.class);
		this.mockMvc.perform(get("/0123489").header(HttpHeaders.AUTHORIZATION, "Bearer " + token)).andDo(print())
				.andExpect(status().isUnauthorized())
				.andExpect(result -> assertTrue(result.getResolvedException() instanceof InvalidTokenException))
				.andExpect(result -> assertEquals("Token is Invalid", result.getResolvedException().getMessage()));
	}

	@Test
	void testPensionerDetailReturnsExceptionOnUnknownAadhaarNumber() throws Exception {
		String token = "dummy";
		when(authProxy.validateToken("Bearer " + token)).thenReturn(true);
		this.mockMvc.perform(get("/0123489").header(HttpHeaders.AUTHORIZATION, "Bearer " + token)).andDo(print())
				.andExpect(status().isNotFound())
				.andExpect(result -> assertTrue(result.getResolvedException() instanceof InvalidPensionerException))
				.andExpect(result -> assertEquals("Aadhaar Number doesn't exist in the database.",
						result.getResolvedException().getMessage()));
	}

}
