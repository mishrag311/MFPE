package com.cts.training.webclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
